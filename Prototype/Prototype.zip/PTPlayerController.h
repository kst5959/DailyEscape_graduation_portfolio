// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "EngineMinimal.h"
#include "GameFramework/PlayerController.h"
#include "PTPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPE_API APTPlayerController : public APlayerController
{
	GENERATED_BODY()

public:

	APTPlayerController();

public:
	//UFUNCTION(Server, Reliable)
	UFUNCTION()
	void DestroyActor(AActor* TargetActor , float Damage);

	//UFUNCTION()
	UFUNCTION(NetMulticast, Reliable)
	void SetWalkSpeed(APrototypeCharacter* PlayerCharacter, float Speed, bool bPressedRun);

	UFUNCTION(NetMulticast, Reliable)
	void SetSurf(APrototypeCharacter* PlayerCharacter, float Speed, bool bPressedSurf);

	UFUNCTION(Server, Reliable)
	void PlayFireMontage(UPTAnimInstance* BodyMeshAnimInstance, APrototypeCharacter* PlayerCharacter);
	
	UFUNCTION(Server, Reliable)
	void PlayReloadMontage(UPTAnimInstance* BodyMeshAnimInstance , APrototypeCharacter* PlayerCharacter);


};

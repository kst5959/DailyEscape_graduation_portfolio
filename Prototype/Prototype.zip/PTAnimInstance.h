// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "EngineMinimal.h"
#include "Animation/AnimInstance.h"
#include "PTAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPE_API UPTAnimInstance : public UAnimInstance
{
	GENERATED_BODY()

public:
	UPTAnimInstance();

	UFUNCTION(NetMulticast, Reliable)
	void TPPPlayFIreMontage();

	UFUNCTION(BlueprintCallable)
	void TPPPlayReloadMontage();

	UFUNCTION(BlueprintCallable)
	void PlayReloadMontage();

	UFUNCTION(BlueprintCallable)
	void PlayFIreMontage();

	bool IsExcuteOnServer;

	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty> & OutLifetimeProps) const;

	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = Fire, meta = (AllowPrivateAccess = true), Replicated)
	UAnimMontage* TPPFireMontage;

	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = Reload, meta = (AllowPrivateAccess = true), Replicated)
	UAnimMontage* TPPReloadMontage;

private:



	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = Reload, meta = (AllowPrivateAccess = true), Replicated)
	UAnimMontage* ReloadMontage;

	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = Reload, meta = (AllowPrivateAccess = true), Replicated)
	UAnimMontage* FireMontage;

};

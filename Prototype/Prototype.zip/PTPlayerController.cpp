// Fill out your copyright notice in the Description page of Project Settings.


#include "PTPlayerController.h"
#include "Net/UnrealNetwork.h"
#include "PrototypeCharacter.h"
#include "PTAnimInstance.h"
#include "PrototypeNPCCharacter.h"


APTPlayerController::APTPlayerController()
{

}
//_Implementation
void APTPlayerController::DestroyActor(AActor* TargetActor, float Damage)
{
	if (ROLE_Authority == GetLocalRole())
	{
		if (TargetActor != nullptr)
		{
			if (TargetActor->ActorHasTag(TEXT("NPC")))
			{
				APrototypeNPCCharacter* NPC = Cast<APrototypeNPCCharacter>(TargetActor);
				UE_LOG(LogTemp, Warning, TEXT("Set NPC HP Server"));
				NPC->SetHP(Damage);
				if (NPC->HP <= 0)
				{
					NPC->Destroy();
				}
			}
		}
	}
}
//_Implementation
void APTPlayerController::SetWalkSpeed_Implementation(APrototypeCharacter* PlayerCharacter, float Speed ,bool bPressedRun)
{
	if (ROLE_Authority ==GetLocalRole())
	{
		if (PlayerCharacter != nullptr)
		{
		
			if (bPressedRun == true)
			{
				PlayerCharacter->GetCharacterMovement()->MaxWalkSpeed = Speed;
				PlayerCharacter->bPressedRun = true;
				UE_LOG(LogTemp, Warning, TEXT("Running %f "), Speed);
			}
			else if (bPressedRun == false)
			{
				
				PlayerCharacter->GetCharacterMovement()->MaxWalkSpeed = Speed;
				PlayerCharacter->bPressedRun = false;
				UE_LOG(LogTemp, Warning, TEXT("Stop Running %f "), Speed);
			}
			
		}
	}

}

void APTPlayerController::SetSurf_Implementation(APrototypeCharacter* PlayerCharacter, float Speed, bool bPressedSurf)
{
	if (ROLE_Authority == GetLocalRole())
	{
		if (PlayerCharacter != nullptr)
		{
			if (bPressedSurf == true)
			{
				PlayerCharacter->GetCharacterMovement()->MaxWalkSpeed = Speed;
				PlayerCharacter->GetCharacterMovement()->SetWalkableFloorAngle(90.0f);
				PlayerCharacter->bPrssedSurf = true;
				UE_LOG(LogTemp, Warning, TEXT("Surf %f "), Speed);
			}
			else if (bPressedSurf == false)
			{
				if (PlayerCharacter->bPressedRun == false)
				{
					PlayerCharacter->GetCharacterMovement()->MaxWalkSpeed = Speed;
				}
				PlayerCharacter->GetCharacterMovement()->SetWalkableFloorAngle(45.0f);
				PlayerCharacter->bPrssedSurf = false;
				UE_LOG(LogTemp, Warning, TEXT("Stop Surf %f "), Speed);
			}

		}
	}

}

void APTPlayerController::PlayFireMontage_Implementation(UPTAnimInstance* BodyMeshAnimInstance, APrototypeCharacter* PlayerCharacter)
{
	if (ROLE_Authority == GetLocalRole())
	{
		if (PlayerCharacter != nullptr)
		{
			PlayerCharacter->SetFireMontagePlay();
		}

		/*fhwk

		if (BodyMeshAnimInstance != nullptr)
		{
			if (!BodyMeshAnimInstance->Montage_IsPlaying(BodyMeshAnimInstance->TPPFireMontage))
			{
				BodyMeshAnimInstance->TPPPlayFIreMontage();
				UE_LOG(LogTemp, Warning, TEXT("Play FireMontage Server"));
			}
	
		}
		*/
	}
}

void APTPlayerController::PlayReloadMontage_Implementation(UPTAnimInstance* BodyMeshAnimInstance, APrototypeCharacter* PlayerCharacter)
{
	if (ROLE_Authority == GetLocalRole())
	{
		if (PlayerCharacter != nullptr)
		{

			//if (!BodyMeshAnimInstance->Montage_IsPlaying(BodyMeshAnimInstance->TPPReloadMontage))
			//{
				UE_LOG(LogTemp, Warning, TEXT("Set Reload Montage On Server"));
				PlayerCharacter->SetReloadMontagePlay();
			//}
			
		}
		
	}
}